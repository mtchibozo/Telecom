package a2017_2018.pact34.teech;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;


public class ExerciseHistoryActivity extends AppCompatActivity implements View.OnClickListener{

    //TODO: get the number of exercises trough the database
    int nbEx = 15;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_history);
        createButtons(nbEx);
    }

    private void createButtons(int nb){
        LinearLayout layout = findViewById(R.id.layout_history);
        for(int i=0; i<nb; i++){
            Button but = new Button(this);
            String text = "Bouton " + Integer.toString(i);

            //TODO: change the attribute with the id of the exercice
            String attribute = "Hello";

            but.setTag(attribute);
            but.setText(text);
            but.setOnClickListener(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            layout.addView(but, lp);
        }
    }

    public void onClick(View v){
        Button b = (Button) v;
        String id = (String) b.getTag();
        Intent intent= new Intent(this, ExercisePageActivity.class);
        intent.putExtra("id", id);
        startActivity(intent);
    }
}
