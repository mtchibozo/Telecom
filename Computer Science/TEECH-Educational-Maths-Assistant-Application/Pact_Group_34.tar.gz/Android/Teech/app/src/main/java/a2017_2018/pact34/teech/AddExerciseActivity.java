package a2017_2018.pact34.teech;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class AddExerciseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_exercise);
    }

    public void  save(View view)  // SAVE
    {
        EditText edittitre = (EditText) findViewById(R.id.EditTitre);
        EditText editenonce = (EditText) findViewById(R.id.EditEnonce);
        File file = null;
        String titre = edittitre.getText().toString();
        String enonce = editenonce.getText().toString();

        FileOutputStream fileOutputStream = null;
        if (titre != null && enonce != null) {
            try {
                titre = titre + " ";
                enonce = "\n" +enonce;
                file = getFilesDir();
                fileOutputStream = openFileOutput("Exercice.txt", Context.MODE_PRIVATE); // écrase le fichier
                fileOutputStream.write(titre.getBytes());
                fileOutputStream.write(enonce.getBytes());
                Toast.makeText(this, "Saved \n" + "Path --" + file + "\tExercice.txt", Toast.LENGTH_SHORT).show();
                edittitre.setText("");
                editenonce.setText("");
                return;
            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                try {
                    fileOutputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
public void returnToMain(View view){
    Intent intent = new Intent(AddExerciseActivity.this, MainActivity.class);
    startActivity(intent);
    finish();
}
}
