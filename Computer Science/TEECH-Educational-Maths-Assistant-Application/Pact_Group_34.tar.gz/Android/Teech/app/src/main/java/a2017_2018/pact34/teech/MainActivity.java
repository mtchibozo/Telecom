package a2017_2018.pact34.teech;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void goToExercisePageActivity(View view){
        Intent intent = new Intent(this,ExercisePageActivity.class);
        Log.d("test", "avant INTENT");
        startActivity(intent);
    }

    public void goToExerciseHistoryActivity(View view){
        Intent intent= new Intent(this,ExerciseHistoryActivity.class);
        startActivity(intent);
    }
    public void goToAddExercise(View view){
        Intent intent= new Intent(this,AddExerciseActivity.class);
        startActivity(intent);
    }
}
