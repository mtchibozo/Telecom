package a2017_2018.pact34.teech;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class RegisterTeacherActivity extends AppCompatActivity {

    private EditText nameView;
    private EditText emailView;
    private EditText passwordView;
    private EditText confirmView;
    private EditText etablissementView;
    private EditText villeView;
    private EditText classeView;
    private EditText specView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_teacher);
        nameView = findViewById(R.id.editTextName);
        emailView = findViewById(R.id.editEmail);
        passwordView = findViewById(R.id.editPassword);
        confirmView = findViewById(R.id.confirmPassword);
        etablissementView = findViewById(R.id.editEtablissement);
        villeView = findViewById(R.id.editVille);
        classeView = findViewById(R.id.editClasse);
        specView = findViewById(R.id.editSpec);
    }


    private boolean isEmailValid(String email) {
        //TODO: Replace this with your own logic and change the tests in the login activities
        return email.contains("@");
    }

    private boolean isPasswordValid(String password) {
        //TODO: Replace this with your own logic and change the tests in the login activities
        return password.length() > 4;
    }


    public void finishTeacher(String mail, String password){
        register(mail, password);
        Intent intent = new Intent(RegisterTeacherActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }


    public void verifyFieldsTeacher(View v){

        // Reset errors.
        nameView.setError(null);
        emailView.setError(null);
        passwordView.setError(null);
        confirmView.setError(null);
        etablissementView.setError(null);
        villeView.setError(null);
        classeView.setError(null);
        specView = findViewById(R.id.editSpec);

        String email = emailView.getText().toString();
        String password = passwordView.getText().toString();
        String confirmation = confirmView.getText().toString();

        boolean cancel = false;
        View focusView = null;


        if(TextUtils.isEmpty(specView.getText().toString())){
            specView.setError(getString(R.string.error_field_required));
            focusView = specView;
            cancel = true;
        }

        if(TextUtils.isEmpty(classeView.getText().toString())){
            classeView.setError(getString(R.string.error_field_required));
            focusView = classeView;
            cancel = true;
        }

        if(TextUtils.isEmpty(villeView.getText().toString())){
            villeView.setError(getString(R.string.error_field_required));
            focusView = villeView;
            cancel = true;
        }

        if(TextUtils.isEmpty(etablissementView.getText().toString())){
            etablissementView.setError(getString(R.string.error_field_required));
            focusView = etablissementView;
            cancel = true;
        }

        // Check if password and password confirmations are equals
        if (!TextUtils.isEmpty(confirmation) && !confirmation.equals(password)) {
            confirmView.setError(getString(R.string.error_incorrect_confirmation));
            focusView = passwordView;
            cancel = true;
        }

        // Check for a valid password, if the user entered one.
        if (!TextUtils.isEmpty(password) && !isPasswordValid(password)) {
            passwordView.setError(getString(R.string.error_invalid_password));
            focusView = passwordView;
            cancel = true;
        }

        if (TextUtils.isEmpty(password) ) {
            passwordView.setError(getString(R.string.error_invalid_password));
            focusView = passwordView;
            cancel = true;
        }

        // Check for a valid email address.
        if (TextUtils.isEmpty(email)) {
            emailView.setError(getString(R.string.error_field_required));
            focusView = emailView;
            cancel = true;
        } else if (!isEmailValid(email)) {
            emailView.setError(getString(R.string.error_invalid_email));
            focusView = emailView;
            cancel = true;
        } else if (emailUsed(email)){
            emailView.setError(getString(R.string.error_used_email));
            focusView = emailView;
            cancel = true;
        }

        if(TextUtils.isEmpty(nameView.getText().toString())){
            nameView.setError(getString(R.string.error_field_required));
            focusView = nameView;
            cancel = true;
        }

        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        } else {
            // Goes to the next step
            finishTeacher(email, password);
        }
    }

    /**
     * Tests if the mail is already in the Accounts file
     */
    private boolean emailUsed(String mail){
        Boolean test = false;
        FileInputStream fr = null;
        BufferedReader br = null;
        File dir = getFilesDir();
        File file = new File(dir + "/Accounts.txt");
        if(file.exists()){
            try {
                fr =  openFileInput("Accounts.txt");
                br = new BufferedReader(new InputStreamReader(fr));
                String line = br.readLine();
                while(line != null){
                    String[] pieces = line.split(":");
                    if(pieces[0].equals(mail)){
                        test = true;
                        break;
                    }
                    line = br.readLine();
                }
            } catch (Exception e) {e.printStackTrace();}
            finally {
                try {
                    br.close();
                    fr.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return test;
    }

    private void register(String mail, String password){
        File file = null;
        FileOutputStream fileOutputStream = null;

        try {
            String account = mail + ":" + password + "\n";
            file = getFilesDir();
            fileOutputStream = openFileOutput("Accounts.txt", MODE_APPEND); //MODE_PRIVATE pour écraser le fichier
            fileOutputStream.write(account.getBytes());
            Toast.makeText(this, "Saved \n" + "Path --" + file + "\tAccounts.txt", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {fileOutputStream.close();}
            catch (IOException e) {e.printStackTrace();}
        }
    }

}
