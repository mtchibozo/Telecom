package a2017_2018.pact34.teech;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

public class RegStudent2 extends AppCompatActivity {

    private String mail;
    private String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg_student2);
        Intent intent = getIntent();
        password = intent.getStringExtra("password");
        mail = intent.getStringExtra("email");
    }

    public void finishStudent(View v){
        register();
        Intent intent = new Intent(RegStudent2.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    /**
     * Registers the new account in a local file
     */
    private void register(){
        File file = null;
        FileOutputStream fileOutputStream = null;

        try {
            String account = mail + ":" + password + "\n";
            file = getFilesDir();
            fileOutputStream = openFileOutput("Accounts.txt", MODE_APPEND); //MODE_PRIVATE pour écraser le fichier
            fileOutputStream.write(account.getBytes());
            Toast.makeText(this, "Saved \n" + "Path --" + file + "\tAccounts.txt", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {fileOutputStream.close();}
            catch (IOException e) {e.printStackTrace();}
        }
    }



}
