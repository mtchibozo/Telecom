package a2017_2018.pact34.teech;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class CorrectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_correction);
    }

    public void goToFeedbackActivity(View view){
        Intent intent = new Intent(this,FeedbackActivity.class);
        startActivity(intent);

    }
}
