package a2017_2018.pact34.teech;


import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ScrollView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

//from https://github.com/lingarajsankaravelu/Katex
import katex.hourglass.in.mathlib.MathView;

public class ExercisePageActivity extends AppCompatActivity {

    private MathView mathView;
    private ScrollView scrollMath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_page);
        mathView = findViewById(R.id.MathView);
        scrollMath = findViewById(R.id.scrollView3);
        initLatex(true); //create the file with the exercice
        load();
        //render();
    }

    public void  load() {
        Log.d("test", "loading");
        FileInputStream fileInputStream = null;
        try {
            File dir = getFilesDir();
            fileInputStream = openFileInput("Exercice.txt");
            int read = -1;
            StringBuffer buffer = new StringBuffer();
            while((read =fileInputStream.read())!= -1){
                buffer.append((char)read);
            }
            String exercice = buffer.toString();
            Log.d("Exercice", exercice);
            mathView.setDisplayText(exercice);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                fileInputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Toast.makeText(this,"Loaded", Toast.LENGTH_SHORT).show();
    }


    public void goToCorrectionActivity(View view){
        Intent intent = new Intent(this, CorrectionActivity.class);
        startActivity(intent);
        }


    //Test function
    private void render() {
        String latex = "TITRE: exercice\nCalculer $\\sum_{k=1}^{n} k^2 $";
        latex = latex.replace("\n", " \\newline " );
        Log.d("test", latex);
        mathView.setDisplayText(latex);
    }



    //function to create a latex file if it doesn't exists
    // le boolean en paramètre sert ici à ne pas réinitialiser quand on entre dans l'activité mais seulent quand on passe l'exercice
    private void initLatex(Boolean checkExistence) {
        FileOutputStream fileOutputStream = null;
        File dir = getFilesDir();
        File test = new File(dir + "/Exercice.txt");
        Boolean writer = !test.exists();
        if(!checkExistence){
            writer =true;
        }
        if (writer) {
            try {
                String latex = "TITRE: exercice\nCalculer $\\sum_{k=1}^{n} k^2$TITRE: exercice\nCalculer $\\sum_{k=1}^{n} k^2$TITRE: exercice\nCalculer $\\sum_{k=1}^{n} k^2$TITRE: exercice\nCalculer $\\sum_{k=1}^{n} k^2$";
                fileOutputStream = openFileOutput("Exercice.txt", MODE_PRIVATE);
                fileOutputStream.write(latex.getBytes());
            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                try {
                    fileOutputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void passe(View v){
        initLatex(false);
        load();
    }
}


